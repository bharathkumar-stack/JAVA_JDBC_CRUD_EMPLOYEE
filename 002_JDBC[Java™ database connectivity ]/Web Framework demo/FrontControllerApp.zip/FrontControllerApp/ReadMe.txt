Hi,


With this web app we can register the details of the person,
once registration is successful that person will be 
able to login into the system.

Request you to validate the project in all the aspects.



