package com.keane.training.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.keane.dbfw.ResultMapper;
import com.keane.training.domain.User;

public class SqlMapper {

	public static final String FETCH_USER = "select name,employeeId,technology,password from user_info where portalid=?";
                          
	public static final ResultMapper MAP_USER = new ResultMapper() {

		@Override
		public Object mapRows(ResultSet rs) throws SQLException {
			User user = new User();
			user.setPassword(rs.getString("password"));
			user.setEmployeeId(rs.getInt("employeeId"));
			return user;
			
		}
	};
	
	
	
	/*
	 * pStmt.setInt(1, user.getPortalID());
				pStmt.setString(2, user.getName());
				pStmt.setInt(3, user.getEmployeeId());
				pStmt.setString(4, user.getTechnology());
				pStmt.setString(5, user.getPassword());
	 * 
	 */

	public static final String ADD_USER = "insert into user_info values(?,?,?,?,?)";

}
/*
<Context docBase="FrontControllerApp" path="/FrontControllerApp" reloadable="true" source="org.eclipse.jst.jee.server:FrontControllerApp">
			<Resource name="jdbc/MyDB"
			auth="container"
			driverClassName="oracle.jdbc.driver.OracleDriver"
			url="jdbc:oracle:thin:@localhost:1521:XE"
			username="TRDB"
			password="TRDB"
			maxActive="20"
			maxIdle="10"
			maxWait="-1"
			/>
			</Context>
*/